﻿using UnityEngine;

public class ClosePanel : MonoBehaviour
{
    [Tooltip("List of panels to manage")]
    public GameObject[] panels;

    private int lastOpenedPanelIndex = -1;

    // Show a specific panel (e.g., called when clicking an element)
    public void ShowPanel(int index)
    {
        if (index >= 0 && index < panels.Length)
        {
            Debug.Log($"Showing panel at index: {index}");
            panels[index].SetActive(true);
            lastOpenedPanelIndex = index;
        }
        else
        {
            Debug.LogWarning($"Invalid panel index: {index}");
        }
    }

    // Hide a specific panel
    public void HidePanel(int index)
    {
        if (index >= 0 && index < panels.Length)
        {
            Debug.Log($"Hiding panel at index: {index}");
            panels[index].SetActive(false);
        }
        else
        {
            Debug.LogWarning($"Invalid panel index: {index}");
        }
    }

    // Optional: Hide all panels
    public void HideAllPanels()
    {
        Debug.Log("Hiding all panels.");
        foreach (GameObject panel in panels)
        {
            panel.SetActive(false);
        }
        lastOpenedPanelIndex = -1;
    }

    // These public methods are used by UI Buttons via OnClick()
    public void HidePanel0() => HidePanel(0);
    public void HidePanel1() => HidePanel(1);
    public void HidePanel2() => HidePanel(2);
}
